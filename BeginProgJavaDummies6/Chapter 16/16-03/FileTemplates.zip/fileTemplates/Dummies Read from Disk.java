/*
 * Before IntelliJ can compile this code,
 * you must fill in the blanks.
 */

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class ${NAME} {

    public static void main(String[] args) throws FileNotFoundException {

        var diskScanner = new Scanner(new File("${Disk_file_name___including_the_extension}"));

        int intVariable = diskScanner.nextInt();
        double doubleVariable = diskScanner.nextDouble();
        String stringVariable = diskScanner.nextLine();
        char charVariable = diskScanner.findWithinHorizon(".",0).charAt(0);

        // Etc.

        diskScanner.close();
    }
}
