/*
 * Before IntelliJ can compile this code,
 * you must fill in the blanks.
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;

public class ${NAME} {

    public static void main(String[] args) throws FileNotFoundException {

        var diskWriter = new PrintStream("${Disk_file_name___including_the_extension}");

        diskWriter.print(anExpression);
        diskWriter.println(anotherExpression);

        // Etc.

        diskWriter.close();
    }
}
